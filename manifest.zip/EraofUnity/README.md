# Era of Unity
    该项目基于Unity所开发的Era类游戏开源框架。UI使用UI Toolkit，支持Unity 2021.2以上版本。
    项目主要完成的目标：
    1. 文字式UI框架
    2. 基本人物类
    3. 数据驱动的口上
    4. 基本的系统功能